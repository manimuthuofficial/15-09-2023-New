All folders directorys not mentioned here. 
Plz check if your needs.